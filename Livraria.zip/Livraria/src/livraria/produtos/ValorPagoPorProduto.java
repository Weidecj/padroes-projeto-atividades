package livraria.produtos;

import livraria.Livraria;

public interface ValorPagoPorProduto {
    public double calcularValor(Livraria valor);
}
