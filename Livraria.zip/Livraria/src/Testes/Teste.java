package Testes;

import livraria.*;
import livraria.produtos.*;

public class Teste {
    
    /*
    public static void main(String[] args) {
        JogosTabuleiro jogo = new JogosTabuleiro();
        RevistasDigitais revista = new RevistasDigitais();
        Livraria produto = new Livraria(10.0);
        
        CalcularValorTotal calculo = new CalcularValorTotal();
        System.out.println(": R$ " + calculo.calcularPreco(produto, jogo));
    }*/
}
